#if (UNITY_STANDALONE_WIN)
using RootSystem = System;
using System.Linq;
using System.Collections.Generic;
namespace Microsoft.Kinect.Face
{
    //
    // Microsoft.Kinect.Face.FaceAlignmentQuality
    //
    public enum FaceAlignmentQuality : int
    {
        High                                     =0,
        Low                                      =1,
    }

}
#endif
